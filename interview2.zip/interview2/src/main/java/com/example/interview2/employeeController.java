package com.example.interview2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employees")
public class employeeController {
	private employeeService EmployeeService ;
	
	@Autowired
	private void employeeController(employeeService EmployeeService) {
		this.EmployeeService=EmployeeService;
	}
	@GetMapping("/get")
	public List<employee> getAllEmployee(){
		return EmployeeService.getAllEmployee();
	}
    @PostMapping
	public employee saveEmployee(@RequestBody employee Employee)
	{
		return EmployeeService.saveEmployee(Employee);
	}
	@DeleteMapping("/{id}")
	public void deleteEmployee(@PathVariable Long id)
	{
	 EmployeeService.deleteEmployee(id);
	}
	
}
