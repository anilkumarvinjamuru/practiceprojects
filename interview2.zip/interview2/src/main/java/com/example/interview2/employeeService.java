package com.example.interview2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class employeeService {
 
   private final employeeRepository EmployeeRepository;
   
   @Autowired
   public employeeService(employeeRepository EmployeeRepository) {
	   this.EmployeeRepository= EmployeeRepository;
   }
   
   public List<employee> getAllEmployee(){
	return EmployeeRepository.findAll();
	   }
   public employee saveEmployee(employee Employee)
   {
	return EmployeeRepository.save(Employee);
	}
   public void deleteEmployee(Long id) {
	 EmployeeRepository.deleteById(id);   
   }
   
}
